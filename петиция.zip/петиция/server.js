const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const helmet = require('helmet');
const fs = require('fs');
const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'change_this_token';
const app = express();
app.use(helmet());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
const dbFolder = path.join(__dirname, 'data');
if(!fs.existsSync(dbFolder)) fs.mkdirSync(dbFolder);
const db = new sqlite3.Database(path.join(dbFolder,'signatures.db'));
db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS signatures (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    phone TEXT NOT NULL UNIQUE,
    ip TEXT,
    fp TEXT,
    ts TEXT NOT NULL
  )`);
});
function extractIP(req){
  const hdr = req.headers['x-forwarded-for'];
  if(hdr) return hdr.split(',')[0].trim();
  return req.socket.remoteAddress || null;
}
function validPhone(phone){
  const digits = String(phone).replace(/\D/g,'');
  return digits.length===11 && digits.startsWith('7');
}
app.get('/api/count', (req,res)=>{
  db.get('SELECT COUNT(*) AS c FROM signatures', [], (err,row)=>{
    if(err) return res.status(500).json({ok:false});
    res.json({ok:true,count: row.c});
  });
});
app.post('/api/sign', (req,res)=>{
  try{
    const { name, city, phone, fp } = req.body||{};
    if(!name||!city||!phone) return res.status(400).json({ok:false,error:'missing'});
    if(!validPhone(phone)) return res.status(422).json({ok:false,error:'bad_phone'});
    const ip = extractIP(req);
    const phoneDigits = String(phone).replace(/\D/g,'');
    db.get('SELECT id FROM signatures WHERE phone = ?', [phoneDigits], (err,row)=>{
      if(err) return res.status(500).json({ok:false,error:'db'});
      if(row) return res.status(409).json({ok:false,error:'duplicate_phone'});
      const ts = new Date().toISOString();
      db.run('INSERT INTO signatures (name,city,phone,ip,fp,ts) VALUES (?,?,?,?,?,?)',
        [name,city,phoneDigits,ip,fp,ts], function(err2){
          if(err2){
            if(err2.code==='SQLITE_CONSTRAINT') return res.status(409).json({ok:false,error:'duplicate'});
            return res.status(500).json({ok:false,error:'db_insert'});
          }
          db.get('SELECT COUNT(*) AS c FROM signatures', [], (e,r)=>{
            res.json({ok:true,id:this.lastID,count:r.c});
          });
        });
    });
  }catch(e){ console.error(e); res.status(500).json({ok:false,error:'server'}); }
});
app.post('/api/sync', (req,res)=>{
  try{
    const items = Array.isArray(req.body) ? req.body : [];
    if(items.length===0) return res.json({ok:true, inserted:0, skipped:0});
    let inserted=0, skipped=0;
    const insertOne = (it, cb) => {
      if(!it.name || !it.city || !it.phone){ skipped++; return cb(); }
      if(!validPhone(it.phone)){ skipped++; return cb(); }
      const phoneDigits = String(it.phone).replace(/\D/g,'');
      db.get('SELECT id FROM signatures WHERE phone = ?', [phoneDigits], (err,row)=>{
        if(err){ skipped++; return cb(); }
        if(row){ skipped++; return cb(); }
        const ts = it.ts || new Date().toISOString();
        const ip = it.ip || null; const fp = it.fp || null;
        db.run('INSERT INTO signatures (name,city,phone,ip,fp,ts) VALUES (?,?,?,?,?,?)', [it.name,it.city,phoneDigits,ip,fp,ts], function(err2){
          if(err2){ skipped++; return cb(); }
          inserted++; return cb();
        });
      });
    };
    let idx=0; const next = ()=>{ if(idx>=items.length) return res.json({ok:true,inserted,skipped}); insertOne(items[idx++], next); }; next();
  }catch(e){ console.error(e); res.status(500).json({ok:false,error:'server'}); }
});
app.get('/api/export', (req,res)=>{
  const token = req.query.token || '';
  if(token !== ADMIN_TOKEN) return res.status(403).send('forbidden');
  res.setHeader('Content-Type','text/csv');
  res.setHeader('Content-Disposition','attachment; filename="signatures.csv"');
  res.write('id,name,city,phone,ip,ts\n');
  db.each('SELECT id,name,city,phone,ip,ts FROM signatures ORDER BY id', [], (err,row)=>{
    if(!err){
      const line = [row.id, '"' + (row.name||'').replace(/"/g,'""') + '"', '"' + (row.city||'').replace(/"/g,'""') + '"', '"' + (row.phone||'').replace(/"/g,'""') + '"', '"' + (row.ip||'').replace(/"/g,'""') + '"', '"' + (row.ts||'') + '"'].join(',');
      res.write(line + '\n');
    }
  }, ()=>{ res.end(); });
});
app.listen(PORT, ()=> console.log('Server listening on', PORT));
