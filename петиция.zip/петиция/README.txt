Petition final deploy package - quick start

1) Unzip this package to a folder on your machine.
2) Install Node.js 18+ and npm.
3) Open terminal in this folder and run:
   npm install
   export ADMIN_TOKEN="your_secret_token"   # on Windows PowerShell: $env:ADMIN_TOKEN="your_secret_token"
   node server.js
4) Open http://localhost:3000 in your browser.
5) The site shows live count (from server). If offline, signatures save locally and auto-sync when online.
6) To export all signatures on the server: open http://localhost:3000/api/export?token=your_secret_token
